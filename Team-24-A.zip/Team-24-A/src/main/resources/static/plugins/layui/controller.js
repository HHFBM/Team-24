layui.config().use([ 'form', 'layer', 'upload', 'laydate', 'tree', 'util' ],
		function() {
			var form = layui.form;
			form.render();
		})
