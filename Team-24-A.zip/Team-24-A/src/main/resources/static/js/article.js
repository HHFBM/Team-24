$(function() {

$("#title").blur(
		function() {
			$("#title_msg").empty();
			var name = $(this).val();
			if (name == "" || name == null) {
				$("#title").after("<span id='title_msg' style='color: red'>标题不能为空</span>");
			}
	});

$("#bannerid").blur(
		function() {
			$("#bannerid_msg").empty();
			var name = $(this).val();
			if (name == "" || name == null) {
				$("#bannerid").after("<span id='bannerid_msg' style='color: red'>栏目不能为空</span>");
			}
	});

$("#image").blur(
		function() {
			$("#image_msg").empty();
			var name = $(this).val();
			if (name == "" || name == null) {
				$("#image").after("<span id='image_msg' style='color: red'>图片不能为空</span>");
			}
	});

$("#contents").blur(
		function() {
			$("#contents_msg").empty();
			var name = $(this).val();
			if (name == "" || name == null) {
				$("#contents").after("<span id='contents_msg' style='color: red'>内容不能为空</span>");
			}
	});







$('#sub').click(function(){
var title = $("#title").val();
var bannerid = $("#bannerid").val();
var image = $("#image").val();
var contents = $("#contents").val();
$("#title_msg").empty();
$("#bannerid_msg").empty();
$("#image_msg").empty();
$("#contents_msg").empty();
if (title == "" || title == null) {
	$("#title").after("<span id='title_msg' style='color: red'>标题不能为空</span>");
	return false;
}
if (bannerid == "" || bannerid == null) {
	$("#bannerid").after("<span id='bannerid_msg' style='color: red'>栏目不能为空</span>");
	return false;
}
if (image == "" || image == null) {
	$("#image").after("<span id='image_msg' style='color: red'>图片不能为空</span>");
	return false;
}
if (contents == "" || contents == null) {
	$("#contents").after("<span id='contents_msg' style='color: red'>内容不能为空</span>");
	return false;
}
});
$('#res').click(function() {
$("#title_msg").empty();
$("#bannerid_msg").empty();
$("#image_msg").empty();
$("#contents_msg").empty();
});

});
