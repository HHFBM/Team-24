1. Project introduction:
    The SpringBoot-based store management system has two roles, administrator and user
    Login management system as an administrator, management system does not exist user operations
    Administrator: user information management, commodity information management, type management, order management, message management, etc

2. Project technology:

    Back-end framework: springboot

    Front-end framework: jsp, css, JavaScript, JQuery

3. Development environment:

- JAVA version: JDK1.8. Other versions are acceptable in theory
- IDE type: IDEA, Eclipse, or Myeclipse. IDEA and Eclipse are recommended
- tomcat version: Tomcat 7.x, 8.x, 9.x, and 10.x are available
- Database version: MySql 5.x
- maven Version: Unlimited
- Hardware environment: Windows or Mac OS

4. System login：
   Website: http://127.0.0.1:8080/admin/index.action
   User name: admin Password: admin

1、项目介绍
基于springboot的商店管理系统存在两种角色，分别为管理员和用户
登入管理系统时以管理员身份，管理系统不存在用户的操作
管理员：用户信息管理、商品信息管理、类型管理、订单管理、留言管理等

2、项目技术

后端框架：springboot

前端框架：jsp、css、JavaScript、JQuery

3、开发环境

- JAVA版本：JDK1.8，其它版本理论上可以
- IDE类型：IDEA、Eclipse、Myeclipse都可以。推荐IDEA与Eclipse
- tomcat版本：Tomcat 7.x、8.x、9.x、10.x版本均可
- 数据库版本：MySql 5.x
- maven版本：无限制
- 硬件环境：Windows 或者 Mac OS

4、系统登陆
   网址：http://127.0.0.1:8080/admin/index.action
   用户名：admin 密码：admin

