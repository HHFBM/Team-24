var navs = [
	{"title": "Admin Info Management","icon": "","spread": false,
	"children": [
		{"title": "Add New Admin", "icon": "", "href": "admin/createAdmin.action"},
		{"title": "Admin Info list", "icon": "", "href": "admin/getAllAdmin.action"},
		{"title": "Admin Info Query", "icon": "", "href": "admin/queryAdminByCond.action"},
		{"title": "Password Reset", "icon": "", "href": "admin/prePwd.action"}]
	},
	{"title": "User Info Management","icon": "","spread": false,
	"children": [
		{"title": "User Info List", "icon": "", "href": "users/getAllUsers.action"},
		{"title": "User Info Query", "icon": "", "href": "users/queryUsersByCond.action"}]
	},
	{"title": "Website Banner Info Management\n","icon": "","spread": false,
	"children": [
		{"title": "Add New Banner", "icon": "", "href": "banner/createBanner.action"},
		{"title": "Banner List", "icon": "", "href": "banner/getAllBanner.action"},
		{"title": "Banner Query", "icon": "", "href": "banner/queryBannerByCond.action"}]
	},
	{"title": "Website Info Management","icon": "","spread": false,
	"children": [
		{"title": "Add New Website Info", "icon": "", "href": "article/createArticle.action"},
		{"title": "Website Info List", "icon": "", "href": "article/getAllArticle.action"},
		{"title": "Website Info Query", "icon": "", "href": "article/queryArticleByCond.action"}]
	},
	{"title": "Goods Type Info Management","icon": "","spread": false,
	"children": [
		{"title": "Add New Goods Type", "icon": "", "href": "cate/createCate.action"},
		{"title": "Goods Type List", "icon": "", "href": "cate/getAllCate.action"},
		{"title": "Goods Type Query", "icon": "", "href": "cate/queryCateByCond.action"}]
	},
	{"title": "Goods Info Management","icon": "","spread": false,
	"children": [
		{"title": "Add New Goods", "icon": "", "href": "goods/createGoods.action"},
		{"title": "Goods Info List", "icon": "", "href": "goods/getAllGoods.action"},
		{"title": "Goods Info Query", "icon": "", "href": "goods/queryGoodsByCond.action"}]
	},
	{"title": "Order Info Management","icon": "","spread": false,
	"children": [
		{"title": "Order Info List", "icon": "", "href": "orders/getAllOrders.action"},
		{"title": "Order Info Query", "icon": "", "href": "orders/queryOrdersByCond.action"},
		{"title": "Order Info statistics", "icon": "", "href": "chart/preChart.action"},
		{"title": "Detailed Order Info List", "icon": "", "href": "details/getAllDetails.action"},
		{"title": "Detailed Order Info Query", "icon": "", "href": "details/queryDetailsByCond.action"}
		]
	},
	/*{"title": "Rate Management","icon": "","spread": false,
	"children": [
		{"title": "Rate List", "icon": "", "href": "topic/getAllTopic.action"},
		{"title": "Rate Query", "icon": "", "href": "topic/queryTopicByCond.action"}]
	},
	{"title": "Comment Management","icon": "","spread": false,
	"children": [
		{"title": "Comment List", "icon": "", "href": "complains/getAllComplains.action"},
		{"title": "Comment Query", "icon": "", "href": "complains/queryComplainsByCond.action"}]
	},
	{"title": "Message Management","icon": "","spread": false,
	"children": [
		{"title": "Message List", "icon": "", "href": "bbs/getAllBbs.action"},
		{"title": "Message Query", "icon": "", "href": "bbs/queryBbsByCond.action"},
		{"title": "Reply List", "icon": "", "href": "rebbs/getAllRebbs.action"},
		{"title": "Reply Query", "icon": "", "href": "rebbs/queryRebbsByCond.action"}
		]
	}*/
];



